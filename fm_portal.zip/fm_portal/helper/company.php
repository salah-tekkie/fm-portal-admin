
<?php
/* Database connection start */

require '../config/config.php';
$config = new config();
$conn = $config->mysqlConfig();

/* Database connection end */


// storing  request (ie, get/post) global array to a variable  
$requestData= $_REQUEST;


$columns = array( 
// datatable column index  => database column name
	0 =>'s_no',
	1 =>'company_id', 
	2 =>'company_name',
	3=> 'company_email',
	4=> 'company_ph',
        5=> 'typ.helper_data_values',
        6=> 'emp.helper_data_values',
        7=> 'company_id',
        8=> 'company_id'
	
);



// getting total number records without any search
$sql = "SELECT (@count:=@count+1) AS s_no, c.company_id,c.company_name,c.company_email,c.company_ph,typ.helper_data_values as type,emp.helper_data_values as noemp FROM (SELECT @count:=0) r, company as c 
INNER JOIN helper_data typ ON typ.helper_data_id = c.company_type
INNER JOIN helper_data emp ON emp.helper_data_id = c.company_emp";

$query=mysqli_query($conn, $sql) or die("helper/branch.php: get cdompany");
$totalData = mysqli_num_rows($query);
$totalFiltered = $totalData;  // when there is no search parameter then total number rows = total number filtered rows.


$sql = "SELECT (@count:=@count+1) AS s_no, c.company_id,c.company_name,c.company_email,c.company_ph,typ.helper_data_values as type,emp.helper_data_values as noemp FROM (SELECT @count:=0) r, company as c 
INNER JOIN helper_data typ ON typ.helper_data_id = c.company_type
INNER JOIN helper_data emp ON emp.helper_data_id = c.company_emp";
if( !empty($requestData['search']['value']) ) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
	$sql.=" WHERE ( c.company_name LIKE '".$requestData['search']['value']."%' ";    
	$sql.=" OR c.company_email LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR c.company_ph LIKE '".$requestData['search']['value']."%' ";
        $sql.=" OR emp.helper_data_values LIKE '".$requestData['search']['value']."%' ";
	$sql.=" OR typ.helper_data_values LIKE '".$requestData['search']['value']."%' )";
	//$sql.=" OR company_office_addr LIKE '".$requestData['search']['value']."%' )";
}
$query=mysqli_query($conn, $sql) or die("helper/branch.php: get company");
$totalFiltered = mysqli_num_rows($query); // when there is a search parameter then we have to modify total number filtered rows as per search result. 
$sql.=" ORDER BY ". $columns[$requestData['order'][0]['column']]."   ".$requestData['order'][0]['dir']."   LIMIT ".$requestData['start']." ,".$requestData['length']."   "; 
/* $requestData['order'][0]['column'] contains colmun index, $requestData['order'][0]['dir'] contains order such as asc/desc , $requestData['start'] contains start row number ,$requestData['length'] contains limit length. */	
$query=mysqli_query($conn, $sql) or die("company.php: get employees");
	

$data = array();

while( $row=mysqli_fetch_array($query) ) {  // preparing an array
	
	//$addr = str_limit($row["company_office_addr"], 7);
	//$addr = substr($row["company_name"], 0, 10);
	$nestedData=array(); 
	$nestedData[] = $row["s_no"];
        $nestedData[] = $row["company_name"];
        $nestedData[] = $row["company_email"];
        $nestedData[] = $row["company_ph"];
        $nestedData[] = $row["type"];
        $nestedData[] = $row["noemp"];
        $nestedData[] = '<a href="index.php?action=view&module=company&post=addform&id='.$row["company_id"].'"><span class="badge badge-pill badge-primary">Edit</span></a>';
        $nestedData[] = '<a onclick=modal(this,"company","preview","dynamicdisplay"); href="#displayprofile" attr-id="'.$row["company_id"].'" class="displayprofile" data-backdrop="static" data-keyboard="false" data-toggle="modal" data-target="#displayprofile"><span class="badge badge-pill badge-primary">View</span></a>';
	
	$data[] = $nestedData;
	
}

$json_data = array(
			"draw"            => intval( $requestData['draw'] ),   // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
			"recordsTotal"    => intval( $totalData ),  // total number of records
			"recordsFiltered" => intval( $totalFiltered ), // total number of records after searching, if there is no searching then totalFiltered = totalData
			"data"            => $data   // total data array
			);

echo json_encode($json_data);  // send data as json format

function check_text($info){
    
    $info = strip_tags($info);
    if(strlen($info) > 20){
        $txt = substr($info, 0, 20)."...";
    }
    else{
        $txt = $info;
    }
    return $txt;
}

?>
