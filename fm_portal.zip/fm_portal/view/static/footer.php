</div>
</div>
    <!-- /#page-content-wrapper -->
    
<script defer src="assets/fontawesome-free-5.11.2-web/js/all.js"></script>
<script defer src="assets/fontawesome-free-5.11.2-web/js/brands.min.js"></script>
<script defer src="assets/fontawesome-free-5.11.2-web/js/fontawesome.min.js"></script>
<script defer src="assets/fontawesome-free-5.11.2-web/js/regular.min.js"></script>
<script defer src="assets/fontawesome-free-5.11.2-web/js/solid.min.js"></script>
<script defer src="assets/fontawesome-free-5.11.2-web/js/v4-shims.min.js"></script>

<!--<script src="assets/js/jquery.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>-->
<script src="assets/js/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="assets/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<!--    datatables-->
<script src="assets/js/jquery.dataTables.min.js"></script>
<script src="assets/js/dataTables.dataTables.min.js"></script>
<script src="assets/js/dataTables.responsive.min.js"></script>
<script src="assets/js/responsive.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/colreorder/1.5.2/js/dataTables.colReorder.min.js"></script>
<script src="https://cdn.datatables.net/scroller/2.0.1/js/dataTables.scroller.min.js"></script>
<script src="https://cdn.datatables.net/fixedheader/3.1.6/js/dataTables.fixedHeader.min.js"></script>
<script src="https://cdn.datatables.net/fixedcolumns/3.3.0/js/dataTables.fixedColumns.min.js"></script>

<!--Cropper--> 
<script src='assets/js/croppie.js'></script>

<!--Custom Script-->
<script src='assets/js/script.js'></script>

    