<?php

class dashboard extends config{

	public function main(){
	$userid = $_SESSION['fm']['portal']['userid'];
	?>
   

   

    
      <div class="container-fluid">
        <h3 class="mt-4">Welcome to Fluidmeet portal</h3>
        <p>Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here </p>
        <p>Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here Sample Text Here </p>
      </div>
    

  

      <?php $this->footer(); ?>

        
    <?php
	}
        public function header() {
            
        }
        
        public function footer() {
            ?>
      
      <?php
        }
	
	 
}
?>