<?php
class company extends config{
    
    public function header() {
        ?>
<style>
    .form-row label{
  margin-bottom: .2rem !important;
}
    .form-row {
  margin-bottom: .5rem !important;
}

</style>
<?php
        
    }
    public function footer() {
        ?>
<script>
		  
			$(document).ready(function(argument) {
			var table = $('#account_dt').DataTable({
				serverSide: true,
				ajax:{
						url :"helper/company.php", // json datasource
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".account_dt-error").html("");
							$("#account_dt").append('<tbody class="account_dt-error"><tr><th colspan="7">No data found in the server</th></tr></tbody>');
							$("#account_dt_processing").css("display","none");
						}
					},
				dom: "frtiS",
				scrollY: 350,
				scrollX: false,
				deferRender: true,
				scrollCollapse: true,
                                drawCallback: function() {
                                    $('[data-toggle="popover"]').popover(),
                                    $('[data-toggle="tooltip-secondary"]').tooltip({
          template: '<div class="tooltip tooltip-secondary" role="tooltip"><div class="arrow"></div><div class="tooltip-inner"></div></div>'
        })      
                                },
				scroller: {
				    loadingIndicator: true
				},
				searching: true
			 
			});
			$('#search_input_dt').keyup(function(){
				  table.search($(this).val()).draw() ;
			})
			
		  	});
			
    	</script>
<?php
    }
    public function preview() {
        
        $misc = new misc();
        $misc->modal();
        if(isset($_REQUEST['id']) and $_REQUEST['id']!=0){
            
            $id = $_REQUEST['id'];
            
            $query = mysqli_query($this->mysqlConfig(),"SELECT c.company_id,c.company_name,c.company_detail,c.company_logo,c.company_web,c.company_geo_lat,c.company_geo_lon,c.company_email,c.company_ph,c.company_lp,typ.helper_data_values as type,emp.helper_data_values as noemp FROM company as c 
INNER JOIN helper_data typ ON typ.helper_data_id = c.company_type
INNER JOIN helper_data emp ON emp.helper_data_id = c.company_emp
WHERE `company_id`=".$id."");
            
            $row = mysqli_fetch_array($query);
            
            $company_name = $row['company_name'];
            $company_detail = $row['company_detail'];
            $company_logo = $row['company_logo'];
            $company_email = $row['company_email'];
            $company_web = $row['company_web'];
            $company_ph = $row['company_ph'];
            //$company_city = $row['company_city'];
            //$company_country = $row['company_country'];
            $company_geo_lat = $row['company_geo_lat'];
            $company_geo_lon = $row['company_geo_lon'];
            $company_type = $row['type'];
            $company_emp = $row['noemp'];
            $company_lp = $row['company_lp'];
            
            $title = 'Edit '.$company_name;
            $post = "update";
            
            
        }
        else{
            $id = 0;
            $title = 'Add Company';
            
            $company_name = '';
            $company_detail = '';
            $company_logo = '';
            $company_email = '';
            $company_web = '';
            $company_ph = '';
            $company_city = '';
            $company_country = '';
            $company_geo_lat = '25.225240';
            $company_geo_lon = '55.262429';
            $company_type = '';
            $company_emp = 0;
            $company_lp = '';
            
            $post = "add";
            
            
        }
        ?>
        <div class="container">
            <h5><?php echo $company_name; ?></h5>
            <div class="row">
                
                <div class="col-4">
                    <?php
                    if($company_logo=="" or $company_logo=="NULL"){
                    ?>
                    <img src="assets/images/logo-sample.jpg" class="gambar img-responsive img-thumbnail" id="item-img-output" width="225"/>
                    <?php
                    } else {
                    ?>
                    <img src="media/<?php echo $company_logo; ?>" class="gambar img-responsive img-thumbnail" id="item-img-output" width="225" />
                    <?php
                    }
                    ?>
                    
                </div>
                <div class="col-8">
                    <div class="p-1"><i class="fas fa-envelope"></i> <?php echo $company_email; ?></div>
                    <div class="p-1"><i class="fas fa-mobile"></i> <?php echo $company_ph; ?></div>
                    <div class="p-1"><i class="fas fa-building"></i> <?php echo $company_type; ?> based company</div>
                    <div class="p-1"><i class="fas fa-user"></i> <?php echo $company_emp; ?> employees</div>
                    <div class="text-left d-flex justify-content-between">
                        <div class="flex-fill bd-highlight"><a href="<?php echo $company_web; ?>"><span class="badge badge-pill badge-primary">Website</span></a></div>
                        <div class="flex-fill bd-highlight text-right"><a href="<?php echo $company_lp; ?>"><span class="badge badge-pill badge-primary">Linkedin</span></a></div>
                            
                    </div>
                    
                </div>
            </div> 
            <hr>
            <div class="row">
                <div class="col-12">
                    <?php echo $company_detail; ?>
                </div>
            </div>
           
           
                       
            <div class="row pt-2 m-1">
                
               
     
                <div class="col-lg-12 col-sm-12 p-2 bg-light border border-left-0" >
                     <div class="row">
             
        <div class="col-sm-12 col-md-12 col-lg-12">
 
        <div id="map"></div>
        <input type='hidden' id='lati' name="company_geo_lat"/>
        <input type='hidden' id='longi' name="company_geo_lon"/>
        
        <script>
        var map;
        var marker;
        var infowindow;
        var messagewindow;
        
        function initMap() {
        /*navigator.geolocation.getCurrentPosition(showPosition);*/
        var location_lat_lan = {lat: 25.225240, lng: 55.262429};
        map = new google.maps.Map(document.getElementById('map'), {
        center: location_lat_lan,
        zoom: 18
        });
        infoWindow = new google.maps.InfoWindow;
        var saved_lat = <?php echo $company_geo_lat; ?>;
        var saved_lon = <?php echo $company_geo_lon; ?>;
        // Try HTML5 geolocation.
        if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
        var pos = {
        lat: <?php echo $company_geo_lat; ?>,
        lng: <?php echo $company_geo_lon; ?>
        };
        
        //infoWindow.setPosition(pos);
        //infoWindow.setContent('Location found.');
        placeMarker(pos);
        infoWindow.open(map);
        map.setCenter(pos);
        if(saved_lat==""){
        document.getElementById('lati').value = position.coords.latitude;
        document.getElementById('longi').value = position.coords.longitude;
        }
        else{
        document.getElementById('lati').value = saved_lat;
        document.getElementById('longi').value = saved_lon;
        }
        
        
        }, function() {
        handleLocationError(true, infoWindow, map.getCenter());
        });
        } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, infoWindow, map.getCenter());
        }
        

        
      
        
        }
        
        function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
        'Error: The Geolocation service failed.' :
        'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
        }	  
        
        
        function placeMarker(location) {
        if ( marker ) {
        marker.setPosition(location);
        } else {
        marker = new google.maps.Marker({
        position: location,
        map: map
        });
        }
        }
        
        
        
        function doNothing () {
        }
        
        </script>
        <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC0kLNj1EjKjykaLppk7iwfv-Bjr04M8fI&callback=initMap">
        </script>
        
        
        </div>
                          
        </div>
                    
                       
           
                </div>
            </div>
                        
            </form>
        </div>
        <?php
    }
    public function tables() {
        ?>
        
        <table id="account_dt" class="cell-border compact stripe" width="100%">
    <thead>
      <tr>
        <th>S.No</th>
        <th>Company</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Company type</th>
        <th>Employees</th>
        <th>Edit</th>
        <th>View</th>
       
      </tr>
    </thead>
</table>
        <?php
        $this->footer();
    }
    public function form() {
        $misc = new misc();
        $misc->modal();
        if(isset($_REQUEST['id']) and $_REQUEST['id']!=0){
            
            $id = $_REQUEST['id'];
            
            $query = mysqli_query($this->mysqlConfig(),"SELECT * FROM `company` where company_id=".$id."");
            $row = mysqli_fetch_array($query);
            
            $company_name = $row['company_name'];
            $company_detail = $row['company_detail'];
            $company_logo = $row['company_logo'];
            $company_email = $row['company_email'];
            $company_web = $row['company_web'];
            $company_ph = $row['company_ph'];
            $company_city = $row['company_city'];
            $company_country = $row['company_country'];
            $company_geo_lat = $row['company_geo_lat'];
            $company_geo_lon = $row['company_geo_lon'];
            $company_type = $row['company_type'];
            $company_emp = $row['company_emp'];
            $company_lp = $row['company_lp'];
            
            $title = 'Edit '.$company_name;
            $post = "update";
            
            
        }
        else{
            $id = 0;
            $title = 'Add Company';
            
            $company_name = '';
            $company_detail = '';
            $company_logo = '';
            $company_email = '';
            $company_web = '';
            $company_ph = '';
            $company_city = '';
            $company_country = '';
            $company_geo_lat = '25.225240';
            $company_geo_lon = '55.262429';
            $company_type = '';
            $company_emp = 0;
            $company_lp = '';
            
            $post = "add";
            
            
        }
        ?>
        <div class="container">
             <form class="needs-validation" novalidate method="post" action="index.php">
                        <input type="hidden" name="module" value="company">
                        <input type="hidden" name="action" value="model">
                        <input type="hidden" name="post" value="<?php echo $post; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <div><h5><?php echo $title; ?></h5></div>
                <div class="d-flex justify-content-end"><button class="btn btn-primary" type="submit">Save</button></div>
            </div>
           
                       
            <div class="row pt-2 m-1">
                
               
        <div class="col-lg-6 col-sm-12 p-2 bg-light border">
                    
                    
                <div class="p-3">         
            
            <div class="form-row">
              <label for="company_name">Company Name</label>
              <input placeholder="" type="text" class="form-control" id="company_name" name="company_name" value="<?php echo $company_name; ?>" required>
              <div class="valid-feedback">
                Looks good!
              </div>
            </div>
            <div class="form-row pt-2">
              <label for="company_detail">Details</label>
              <textarea name="company_detail"  class="form-control" aria-label="With textarea" required=""><?php echo $company_detail; ?></textarea>
              <div class="valid-feedback">
                Looks good!
              </div>
            </div>
                       <div class="form-row pt-2">
                        <span>Company Type</span>
                    </div>
                        
            <div class="form-check pt-2">
                
                <?php $misc->radio_value(1,$company_type,'company_type'); ?>
              </div>
                    
            <div class="form-row pt-2">
              <label for="district">Employee range</label>
              <select class="custom-select" id="company_emp" name="company_emp" required>
                <option label="Choose one"></option>
                 <?php $misc->option_value(2,$company_emp); ?>
              </select>
              <div class="invalid-feedback">
                Please select a valid state.
              </div>
            </div>
            <div class="form-row pt-2">
              <label for="company_email">Email</label>
              <input placeholder="you@domain.com" type="email" class="form-control" id="company_email" name="company_email" value="<?php echo $company_email; ?>" required>
              <div class="valid-feedback">
                Looks good!
              </div>
            </div>
            <div class="form-row pt-2">
              <label for="company_ph">Telephone</label>
              <input placeholder="+971 505050505" type="tel" pattern="[\+]\d{3} \d{9}" class="form-control" id="company_ph" name="company_ph" value="<?php echo $company_ph; ?>" required>
              <div class="valid-feedback">
                Looks good!
              </div>
            </div>
            <div class="form-row pt-2">
              <label for="company_web">Website</label>
              <input placeholder="http://example.com" type="url" class="form-control" id="company_web" name="company_web" value="<?php echo $company_web; ?>" required>
              <div class="valid-feedback">
                Looks good!
              </div>
            </div>
                     <div class="form-row pt-2">
              <label for="company_lp">linkedin Profile</label>
              <input  type="text" class="form-control" id="company_lp" name="company_lp" value="<?php echo $company_lp; ?>">
              <div class="valid-feedback">
                Looks good!
              </div>
            </div>
        
                </div>

                </div>
                <div class="col-lg-6 col-sm-12 p-2 bg-light border border-left-0" >
                     <div class="row">
             
        <div class="col-sm-12 col-md-12 col-lg-12">
           
        <div class="form-row pt-3">
              <label for="company_name">Company Location</label>
             <div id="map"></div>
            </div>
        
        <input type='hidden' id='lati' name="company_geo_lat"/>
        <input type='hidden' id='longi' name="company_geo_lon"/>
        
        <script>
        var map;
        var marker;
        var infowindow;
        var messagewindow;
        
        function initMap() {
        /*navigator.geolocation.getCurrentPosition(showPosition);*/
        var location_lat_lan = {lat: 25.225240, lng: 55.262429};
        map = new google.maps.Map(document.getElementById('map'), {
        center: location_lat_lan,
        zoom: 18
        });
        infoWindow = new google.maps.InfoWindow;
        var saved_lat = <?php echo $company_geo_lat; ?>;
        var saved_lon = <?php echo $company_geo_lon; ?>;
        // Try HTML5 geolocation.
        if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(position) {
        var pos = {
        lat: <?php echo $company_geo_lat; ?>,
        lng: <?php echo $company_geo_lon; ?>
        };
        
        //infoWindow.setPosition(pos);
        //infoWindow.setContent('Location found.');
        placeMarker(pos);
        infoWindow.open(map);
        map.setCenter(pos);
        if(saved_lat==""){
        document.getElementById('lati').value = position.coords.latitude;
        document.getElementById('longi').value = position.coords.longitude;
        }
        else{
        document.getElementById('lati').value = saved_lat;
        document.getElementById('longi').value = saved_lon;
        }
        
        
        }, function() {
        handleLocationError(true, infoWindow, map.getCenter());
        });
        } else {
        // Browser doesn't support Geolocation
        handleLocationError(false, infoWindow, map.getCenter());
        }
        

        
        google.maps.event.addListener(map, 'click', function(event) {
        placeMarker(event.latLng);
        var latlng = marker.getPosition();
        document.getElementById('lati').value = latlng.lat();
        document.getElementById('longi').value = latlng.lng();
        });
        
        }
        
        function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
        'Error: The Geolocation service failed.' :
        'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
        }	  
        
        
        function placeMarker(location) {
        if ( marker ) {
        marker.setPosition(location);
        } else {
        marker = new google.maps.Marker({
        position: location,
        map: map
        });
        }
        }
        
        
        
        function doNothing () {
        }
        
        </script>
        <script async defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyC0kLNj1EjKjykaLppk7iwfv-Bjr04M8fI&callback=initMap">
        </script>
        
        
        </div>
                          <div class="col-sm-12 col-md-12 col-lg-12 p-4">
      <label for="crop_final_data">Photo</label>
      <span class="badge badge-info">Minimum size of the logo is 250 x 150 & Format of logo (.jpeg, .jpg)</span>
      
    
    
        <div class="input-group mb-3 pb-3">
          

    <label class="cabinet center-block">
        <figure class="crop_logo">
	<?php
	
    if($company_logo=="" or $company_logo=="NULL"){
    ?>
    
     <img src="assets/images/logo-sample.jpg" class="gambar img-responsive img-thumbnail" id="item-img-output" width="225"/>
	<?php
    } else {
    ?>
  <img src="media/<?php echo $company_logo; ?>" class="gambar img-responsive img-thumbnail" id="item-img-output" width="225" />
    <?php
    }
    ?>	
        
    <input type="hidden" name="crop_final_data" id="crop_final_data" value=""  />
    <figcaption><i class="fa fa-camera"></i></figcaption>
    </figure>
    <input type="file" class="item-img file center-block form-control custom-file-input" name="file_photo"/>
    </label>
    </div>
       	
      <div class="invalid-feedback">
        Please provide a logo.
      </div>
    </div>
        </div>
                    
                       
           
                </div>
            </div>
                        
            </form>
        </div>
        <?php
        
    }
    public function lists(){ 
        $this->header();
        $misc = new misc();
        $misc->modal();
            ?>
        
        <div class="container">
            <div class="pb-2 mt-4 mb-2 border-bottom w-50">
                <h5>Companies</h5>
            </div>
            <div class="row pt-2 m-1">
                
                <div class="col-12">
                    <?php $this->tables(); ?>
                </div>
            </div>
        </div>


<?php
        }
}


