<?php

class company extends config{
    
    public function add() {
        $mysqli = $this->mysqlConfig();
                
        $company_name = $mysqli->real_escape_string($_POST['company_name']);
        $company_detail = $mysqli->real_escape_string($_POST['company_detail']);
        $company_email = $mysqli->real_escape_string($_POST['company_email']);
        $company_web = $mysqli->real_escape_string($_POST['company_web']);
        $company_ph = $_POST['company_ph'];
        $company_geo_lat = $_POST['company_geo_lat'];
        $company_geo_lon = $_POST['company_geo_lon'];
        $company_type = $_POST['company_type'];
        $company_emp = $_POST['company_emp'];
        $company_lp = $mysqli->real_escape_string($_POST['company_lp']);
        
        //Image with crop
	if (isset($_POST['crop_final_data']) and $_POST['crop_final_data']!=""){
            $croped_image = $_POST['crop_final_data'];
            list(, $croped_image)      = explode(',', $croped_image);
            $croped_image = base64_decode($croped_image);
            $name_logo = microtime().'.jpg';
            $name_logo = str_replace(' ', '_', $name_logo);
            file_put_contents('media/'.$name_logo, $croped_image);
	}
	else{
            $name_logo="";
	}
        
        $query = "INSERT INTO `company` 
        (`company_name`, `company_detail`, `company_logo`, `company_email`, `company_web`, `company_ph`, `company_geo_lat`, `company_geo_lon`, `company_type`, `company_emp`, `company_lp`) 
        VALUES 
        ('$company_name', '$company_detail', '$name_logo', '$company_email', '$company_web', '$company_ph', '$company_geo_lat', '$company_geo_lon', '$company_type', '$company_emp', '$company_lp');";
        
            ?>
<div class="container">
    <div class="row pt-4">
        <div class="col-12">
            
        
    <?php
    if (!mysqli_query($this->mysqlConfig(),$query)) {
			//echo("Add Company" . mysqli_error($this->mysqlConfig()));
			?>
            <div class="alert alert-danger mg-b-0" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i style="font-size: 14px;" class="fa fa-window-close"></i>
            </button>
            <strong>Oh snap!</strong> Change a few things up and try submitting again.
          </div>
            <?php
			
		} else { ?>
        <div class="alert alert-primary" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i style="font-size: 14px;" class="fa fa-window-close"></i>
            </button>
            <strong>Well done!</strong> You successfully read this important alert message.
          </div>
        <?php } ?>
            </div>
    </div>
</div>
<?php

    }
    
    public function update() {
        $mysqli = $this->mysqlConfig();
        
        $company_id = $_POST['id'];
        $company_name = $mysqli->real_escape_string($_POST['company_name']);
        $company_detail = $mysqli->real_escape_string($_POST['company_detail']);
        $company_email = $mysqli->real_escape_string($_POST['company_email']);
        $company_web = $mysqli->real_escape_string($_POST['company_web']);
        $company_ph = $_POST['company_ph'];
        $company_geo_lat = $_POST['company_geo_lat'];
        $company_geo_lon = $_POST['company_geo_lon'];
        $company_type = $_POST['company_type'];
        $company_emp = $_POST['company_emp'];
        $company_lp = $mysqli->real_escape_string($_POST['company_lp']);
        
        $query = "";
        //Image with crop
	if (isset($_POST['crop_final_data']) and $_POST['crop_final_data']!=""){
            $croped_image = $_POST['crop_final_data'];
            list(, $croped_image)      = explode(',', $croped_image);
            $croped_image = base64_decode($croped_image);
            $name_logo = microtime().'.jpg';
            $name_logo = str_replace(' ', '_', $name_logo);
            file_put_contents('media/'.$name_logo, $croped_image);
            $query.= "UPDATE `company` SET
        `company_logo`= '$name_logo'
        WHERE `company_id` = ".$company_id.";";
	}
	
        $query.= "UPDATE `company` SET
        `company_name` = '$company_name', 
        `company_detail` = '$company_detail', 
        `company_email`= '$company_email',
        `company_web`= '$company_web',
        `company_ph`= '$company_ph',
        `company_geo_lat`= '$company_geo_lat',
        `company_geo_lon`= '$company_geo_lon',
        `company_type`= '$company_type',
        `company_emp`= '$company_emp',
        `company_lp`= '$company_lp'
        WHERE `company_id` = ".$company_id.";";
        
        
            ?>
<div class="container">
    <div class="row pt-4">
        <div class="col-12">
            
        
    <?php
    if (!mysqli_query($this->mysqlConfig(),$query)) {
			//echo("Add Company" . mysqli_error($this->mysqlConfig()));
			?>
            <div class="alert alert-danger mg-b-0" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i style="font-size: 14px;" class="fa fa-window-close"></i>
            </button>
            <strong>Oh snap!</strong> Change a few things up and try submitting again.
          </div>
            <?php
			
		} else { ?>
        <div class="alert alert-primary" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <i style="font-size: 14px;" class="fa fa-window-close"></i>
            </button>
            <strong>Well done!</strong> You successfully read this important alert message.
          </div>
        <?php } ?>
            </div>
    </div>
</div>
<?php

    
    }
    
}


