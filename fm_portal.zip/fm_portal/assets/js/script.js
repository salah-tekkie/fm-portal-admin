//Croppie

var $uploadCrop,
tempFilename,
rawImg,
imageId;

function readFile(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function (e) {
			$('.upload-demo').addClass('ready');
			$('#cropImagePop').modal('show');
			rawImg = e.target.result;
		}
		reader.readAsDataURL(input.files[0]);
	}
	else {
		swal("");
	}
}

$uploadCrop = $('#upload-demo').croppie({
	viewport: {
		width: 250,
		height: 150,
	},
	enforceBoundary: false
	
});
$('#cropImagePop').on('shown.bs.modal', function(){
        // alert('Shown pop');
        $uploadCrop.croppie('bind', {
                url: rawImg
        }).then(function(){
                console.log('jQuery bind complete');
        });
});

$('.item-img').on('change', function () { 

var ext = $(this).val().split('.').pop().toLowerCase();

	if($.inArray(ext, ['jpg','jpeg']) == -1) {
		alert('Invalid file format. choose only .JPEG format');
	}
	else{
		imageId = $(this).data('id'); tempFilename = $(this).val();
		$('#cancelCropBtn').data('id', imageId); readFile(this); 
	}
	
	
	});
$('#cropImageBtn').on('click', function (ev) {
	$uploadCrop.croppie('result', {
		type: 'base64',
		format: 'jpeg',
		quality: 1,
		size: 'original',
		backgroundColor:'white'
	}).then(function (resp) {
		$('#item-img-output').attr('src', resp);
		$('#crop_final_data').attr('value', resp);
	$('#cropImagePop').modal('hide');


$('#cropImagePop').modal('hide');
});
});

//End Croppie


//Menu
    $("#menu-toggle").click(function(e) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
// End Menu


// form validation
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
// end form validation

// Modal common ajax
function modal(e,module,post,display){
        clear_value();
        var id=$(e).attr('attr-id');
        $.ajax({url:"index.php?module="+module+"&action=view&post="+post+"&id="+id,cache:false,success:function(result){
        $("#"+display+"").html(result);
        }});
}
// End Modal common ajax

function clear_value(){
        $(".form-control").attr("value","");
}


