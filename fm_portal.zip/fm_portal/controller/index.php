<?php

class indexcontroller extends config{

    public function index() {
        
        require("config/instance.php");
			
		if(empty($_SESSION['fm']['portal']['userid'])){
			require("helper/controller/unsession.php");
                        
		}
		else{
			if(isset($_REQUEST['action']) and $_REQUEST['action'] == "config" and $_REQUEST['module'] == "session" and $_REQUEST['post']=="clear"){
                            require("view/static/header.php");
                            $instanceClass->clear();
                            require("view/static/footer.php");
			}
                        //Companies
                        elseif(isset($_REQUEST['action']) and $_REQUEST['action'] == "view" and $_REQUEST['module'] == "company" and $_REQUEST['post']=="lists"){
                            require("view/static/header.php");
                            $instanceClass->lists();
                            require("view/static/footer.php");
                        }
                        elseif(isset($_REQUEST['action']) and $_REQUEST['action'] == "view" and $_REQUEST['module'] == "company" and $_REQUEST['post']=="addform"){
                            require("view/static/header.php");
                            $instanceClass->form();
                            require("view/static/footer.php");
                        }
                        elseif(isset($_REQUEST['action']) and $_REQUEST['action'] == "model" and $_REQUEST['module'] == "company" and $_REQUEST['post']=="add"){
                            require("view/static/header.php");
                            $instanceClass->add();
                            require("view/static/footer.php");
                        }
                        elseif(isset($_REQUEST['action']) and $_REQUEST['action'] == "model" and $_REQUEST['module'] == "company" and $_REQUEST['post']=="update"){
                            require("view/static/header.php");
                            $instanceClass->update();
                            require("view/static/footer.php");
                        }
                         elseif(isset($_REQUEST['action']) and $_REQUEST['action'] == "view" and $_REQUEST['module'] == "company" and $_REQUEST['post']=="preview"){
                            $instanceClass->preview();
                        }
                        
                        else{
                            require("view/static/header.php");
                            require("view/dashboard/dashboard.php");
                            $dashboard = new dashboard();
                            $dashboard->main();
                            require("view/static/footer.php");
                        }
		}
    }

   

}
?>