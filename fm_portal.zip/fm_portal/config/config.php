<?php

class config {
	
	public function mysqlConfig(){
		
       
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "fm_portal";
		
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        return $conn;

		
	}

		
}

?>